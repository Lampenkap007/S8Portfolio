const eventSource = new EventSource("http://localhost:1234/events");

eventSource.onmessage = function (event) {
  const data = JSON.parse(event.data);
  console.log(JSON.parse(event.data));

  // Display on HTML page
  const eventList = document.getElementById("events");
  const listItem = document.createElement("li");
  listItem.textContent = `Event: ${data.event}, Data: ${data.data}`;
  eventList.appendChild(listItem);
};

eventSource.onerror = function (error) {
  console.error("EventSource failed:", error);
};
