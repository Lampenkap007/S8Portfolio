const fs = require("fs");
const zlib = require("zlib");
const readline = require("readline");
const axios = require("axios");
const express = require("express");
const app = express();
const PORT = 3000;
const timingData = [];

if (process.argv[2] === undefined) {
  console.log("No data source provided");
  process.exit();
}

const fileURL = process.argv[2];
const folderName = fileURL.split("/")[5];

try {
  if (!fs.existsSync("./PositionData/")) {
    fs.mkdirSync("./PositionData/");
  }
} catch (err) {
  console.error(err);
}

try {
  if (!fs.existsSync("./PositionData/" + folderName)) {
    fs.mkdirSync("./PositionData/" + folderName);
  }
} catch (err) {
  console.error(err);
}

function timeToMilliseconds(timeStr) {
  const parts = timeStr.split(":");
  const hours = +parts[0];
  const minutes = +parts[1];
  const secondsParts = parts[2].split(".");
  const seconds = +secondsParts[0];
  const milliseconds = secondsParts[1] ? +secondsParts[1] : 0;
  return hours * 3600000 + minutes * 60000 + seconds * 1000 + milliseconds;
}

const readJsonStream = async (filePath) => {
  const stream = fs.createReadStream(filePath, "utf8");
  const reader = readline.createInterface({ input: stream });

  reader.on("line", (line) => {
    const time =
      Math.round(timeToMilliseconds(line.split('"')[0]) / 1000) * 1000;
    timingData.push(time);

    const decoded = Buffer.from(line.split('"')[1], "base64");
    zlib.inflateRaw(decoded, (err, buffer) => {
      if (err) {
        console.error("Failed to decompress:", err);
      } else {
        fs.writeFile(
          "./PositionData/" + folderName + "/" + time + ".json",
          buffer.toString(),
          (err) => {
            if (err) {
              console.error(err);
            }
          }
        );
      }
    });
  });

  reader.on("close", () => {
    console.log("Finished reading the file, starting the server!");
    let time = 8000000;

    app.get("/data", (req, res) => {
      console.log("Client connected");
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Access-Control-Allow-Origin", "*");

      const interval = setInterval(() => {
        if (timingData.includes(time)) {
          fs.readFile(
            "PositionData/" + folderName + "/" + time + ".json",
            "utf8",
            (err, data) => {
              if (err) {
                console.error("Failed to read data", err);
                // Send a comment line to keep the connection alive
                res.write(": error reading data\n\n");
                return;
              }
              try {
                const jsonData = JSON.parse(data);
                res.write(`data: ${JSON.stringify(jsonData)}\n\n`);
              } catch (e) {
                console.error("Failed to parse JSON data in file:" + time, e);
                // Send a comment line to keep the connection alive
                res.write(": error parsing JSON data\n\n");
              }
            }
          );
        }
        time += 1000;
      }, 1000);

      res.on("close", () => {
        console.log("Client closed connection");
        clearInterval(interval); // clear the interval on client disconnect
        res.end();
      });
    });
    app.listen(PORT, () => {
      console.log(
        `Serving ${folderName} positiondata on http://localhost:${PORT}/data`
      );
    });
  });
};

async function downloadFile(url, localPath) {
  const response = await axios({
    method: "GET",
    url: url,
    responseType: "stream",
  });

  const writer = fs.createWriteStream(localPath);

  response.data.pipe(writer);

  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}

downloadFile(
  fileURL,
  "PositionData/" + folderName + "/" + folderName + ".jsonStream"
)
  .then(() => {
    console.log(
      "File downloaded to PositionData/" +
        folderName +
        "/" +
        folderName +
        ".jsonStream"
    );
    readJsonStream(
      "PositionData/" + folderName + "/" + folderName + ".jsonStream"
    );
  })
  .catch((error) => {
    console.error(`Error downloading file: ${error.message}`);
  });
