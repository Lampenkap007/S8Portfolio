const axios = require("axios");
const WebSocket = require("ws");
const zlib = require("zlib");
const fs = require("fs");
const url = require("url");
const express = require("express");
const app = express();
const PORT = 3000;

const FORMULA_1_API = {
  negotiatePath: "https://livetiming.formula1.com/signalr/negotiate",
  connectPath: "wss://livetiming.formula1.com/signalr/connect",
  connectionData: '[{"name":"Streaming"}]',
  subscriptions:
    '{"H":"Streaming","M":"Subscribe","A":[["ArchiveStatus", "ContentStreams", "TrackStatus", "SessionData", "ExtrapolatedClock", "ChampionshipPrediction", "CarData.z", "Position.z", "SessionStatus", "TyreStintSeries", "TimingAppData", "TimingStats", "DriverList", "TimingDataF1", "LapSeries", "TimingData", "TopThree", "DriverRaceInfo", "LapCount", "Heartbeat", "WeatherData", "RaceControlMessages", "TeamRadio", "CurrentTyres", "PitLaneTimeCollection"]],"I":1}',
};

const dataDirectory = "./LivePositionData";
const folderName = "RawData";

function ensureDirectoryExists(path) {
  if (!fs.existsSync(path)) {
    fs.mkdirSync(path, { recursive: true });
  }
}

function negotiateConnection() {
  return axios.get(FORMULA_1_API.negotiatePath, {
    params: {
      connectionData: FORMULA_1_API.connectionData,
      clientProtocol: "1.5",
    },
  });
}

function connectToWebSocket(negotiateData) {
  const queryParams = new url.URLSearchParams({
    transport: "webSockets",
    connectionData: FORMULA_1_API.connectionData,
    connectionToken: negotiateData.data.ConnectionToken,
    clientProtocol: "1.5",
  });

  const headers = {
    Cookie: negotiateData.headers["set-cookie"],
  };

  return new WebSocket(`${FORMULA_1_API.connectPath}?${queryParams}`, {
    headers,
  });
}

function subscribeToUpdates(ws) {
  ws.on("open", () => {
    console.log("Connected to the server");
    setInterval(() => ws.send(FORMULA_1_API.subscriptions), 1000);
  });

  ws.on("error", (err) => console.error("Failed to connect:", err));
}

let subscribers = []; // Hold connected clients

app.get("/data", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  subscribers.push(res);
  req.on(
    "close",
    () => (subscribers = subscribers.filter((sub) => sub !== res))
  );
});

function setupWebSocketMessageHandler(ws) {
  let iteration = 0;
  ws.on("message", (message) => {
    let decodedMessage = Buffer.from(message, "base64").toString("ascii");
    if (decodedMessage.startsWith('{"R"')) {
      iteration++;
      fs.writeFile(
        `${dataDirectory}/${folderName}/${iteration}.json`,
        decodedMessage,
        (writeErr) => {
          if (writeErr) console.error(writeErr);
        }
      );
    }
  });
}

ensureDirectoryExists(`${dataDirectory}/${folderName}`);
negotiateConnection()
  .then((negotiateData) => {
    const ws = connectToWebSocket(negotiateData);
    subscribeToUpdates(ws);
    setupWebSocketMessageHandler(ws);
  })
  .catch(console.error);

app.listen(PORT, () => {
  console.log(
    `Serving ${folderName} position data on http://localhost:${PORT}/data`
  );
});
