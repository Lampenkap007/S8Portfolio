const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const port = 3000;

// Serve static files from a public directory
app.use(express.static("public"));

// Endpoint for Server-Sent Events
app.get("/events", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Connection", "keep-alive");

  // Function to read and send file content
  let fileId = 1140; //Start race: 835
  const sendFileContent = () => {
    const filePath = path.join(__dirname, "VegasF1Data", `${fileId}.json`);
    console.log(filePath);

    if (fs.existsSync(filePath)) {
      fs.readFile(filePath, (err, data) => {
        if (err) {
          console.error(err);
          return;
        }
        res.write(`data: ${data}\n\n`);
        fileId++;
      });
    } else {
      clearInterval(interval);
      res.end(); // End the SSE connection when no more files are found
    }
  };

  // Send file content every 1000 milliseconds
  const interval = setInterval(sendFileContent, 1000);

  // Close the connection when client disconnects
  req.on("close", () => {
    clearInterval(interval);
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
