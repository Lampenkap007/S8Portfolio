const WebSocket = require("ws");
const http = require("http");
const fs = require("fs");
const zlib = require("zlib");
const express = require("express");
const axios = require("axios");
const readline = require("readline");

let fileURL;
let folderName;

const app = express();
const server = http.createServer(app);

app.get("/f1datayears", async (req, res) => {
  try {
    const response = await axios.get(
      "https://livetiming.formula1.com/static/Index.json"
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).send("Error fetching F1 data");
  }
});

app.get("/f1dataevents", async (req, res) => {
  const externalUrl = req.query.url; // Get URL from query parameter
  // Validate and sanitize the externalUrl here
  try {
    const response = await axios.get(externalUrl);
    res.json(response.data);
  } catch (error) {
    res.status(500).send("Error fetching F1 data");
  }
});

// Serve static files from 'public' folder
app.use(express.static("public"));

// Attach WebSocket server to the HTTP server
const wss = new WebSocket.Server({ server });

wss.on("connection", (ws) => {
  console.log("New client connected!");

  ws.on("message", (message) => {
    fileURL = message.toString();
    folderName = fileURL.split("/")[5];

    console.log("Downloading " + folderName);

    try {
      if (!fs.existsSync("./PositionData/")) {
        fs.mkdirSync("./PositionData/");
      }
    } catch (err) {
      console.error(err);
    }

    try {
      if (!fs.existsSync("./PositionData/" + folderName)) {
        fs.mkdirSync("./PositionData/" + folderName);
      }
    } catch (err) {
      console.error(err);
    }

    downloadFile(
      fileURL,
      "PositionData/" + folderName + "/" + folderName + ".jsonStream"
    )
      .then(() => {
        console.log("File downloaded!");

        readJsonStream(
          "PositionData/" + folderName + "/" + folderName + ".jsonStream",
          ws
        );
      })
      .catch((error) => {
        console.error(`Error downloading file: ${error.message}`);
      });
  });

  ws.on("close", () => {
    console.log("Client has disconnected.");
  });
});

function timeToMilliseconds(timeStr) {
  const parts = timeStr.split(":");
  const hours = +parts[0];
  const minutes = +parts[1];
  const secondsParts = parts[2].split(".");
  const seconds = +secondsParts[0];
  const milliseconds = secondsParts[1] ? +secondsParts[1] : 0;
  return hours * 3600000 + minutes * 60000 + seconds * 1000 + milliseconds;
}

const readJsonStream = async (filePath, ws) => {
  const stream = fs.createReadStream(filePath, "utf8");
  const reader = readline.createInterface({ input: stream });

  reader.on("line", (line) => {
    const time =
      Math.round(timeToMilliseconds(line.split('"')[0]) / 1000) * 1000;
    const decoded = Buffer.from(line.split('"')[1], "base64");

    zlib.inflateRaw(decoded, (err, buffer) => {
      if (err) {
        console.error("Failed to decompress:", err);
      } else {
        // Call the function to process and send the data
        processAndSendData(ws, buffer, folderName, time);
      }
    });
  });

  reader.on("close", () => {
    console.log("Finished processing the file.");
  });
};

function processAndSendData(ws, buffer) {
  const data = JSON.parse(buffer.toString());

  Object.keys(data.Position[0].Entries).forEach((key) => {
    const entry = data.Position[0].Entries[key];
    if (entry.X != 0 && entry.Y != 0) {
      ws.send(
        JSON.stringify({
          X: entry.X,
          Y: entry.Y,
        })
      );
    }
  });
}

async function downloadFile(url, localPath) {
  const response = await axios({
    method: "GET",
    url: url,
    responseType: "stream",
  });

  const writer = fs.createWriteStream(localPath);

  response.data.pipe(writer);

  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}

console.log("WebSocket server started on ws://localhost:8080");

// Listen on port 8080
server.listen(8080, () => {
  console.log("Server is running on http://localhost:8080");
});
